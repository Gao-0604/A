### Rank_Suit_Isolator.py (MaixCam Pro 适配版)
###
### 功能：拍摄每张牌的照片，自动裁剪并保存点数/花色训练图像。
###
### 原作者: Evan Juras
### 适配说明:
###   1. PiCamera 替换为 maix.camera
###   2. cv2.imshow/waitKey 替换为 maix.display + maix.touchscreen
###   3. OpenCV 4.x findContours 返回 2 个值
###   4. 按触摸屏拍照（代替键盘 "p" 键）；触摸屏确认保存（代替 "c" 键）
###

import cv2
import numpy as np
import os
import time

import Cards

from maix import camera as maix_camera
from maix import image   as maix_image
from maix import display, touchscreen, app

### -------- 路径与尺寸配置 -------- ###
img_path  = os.path.dirname(os.path.abspath(__file__)) + '/Card_Imgs/'
IM_WIDTH  = 640
IM_HEIGHT = 480

RANK_WIDTH  = 70
RANK_HEIGHT = 125
SUIT_WIDTH  = 70
SUIT_HEIGHT = 100

### -------- 硬件初始化 -------- ###
cam  = maix_camera.Camera(IM_WIDTH, IM_HEIGHT, maix_image.Format.FMT_BGR888)
disp = display.Display()
ts   = touchscreen.TouchScreen()

### -------- 辅助函数 -------- ###

def wait_touch_release(prompt_img=None):
    """
    阻塞等待用户触摸屏幕一次（按下后抬起视为一次点击）。
    可选：传入 prompt_img（maix.image.Image）在等待期间持续显示。
    """
    # 等待按下
    while not app.need_exit():
        if prompt_img is not None:
            disp.show(prompt_img)
        x, y, pressed = ts.read()
        if pressed:
            break
    # 等待抬起，防止连续触发
    while not app.need_exit():
        x, y, pressed = ts.read()
        if not pressed:
            break

def show_cv_image(cv_img):
    """将 OpenCV BGR numpy 图像显示到 MaixCam Pro 屏幕"""
    maix_img = maix_image.cv2image(cv_img, bgr=True, copy=False)
    disp.show(maix_img)

def capture_frame():
    """从摄像头读取一帧，返回 BGR numpy 数组"""
    img = cam.read()
    if img is None:
        return None
    return maix_image.image2cv(img, ensure_bgr=True, copy=True)

### -------- 主流程 -------- ###

i = 1  # 计数器：1-13 为点数，14-17 为花色

for Name in ['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven',
             'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King',
             'Spades', 'Diamonds', 'Clubs', 'Hearts']:

    if app.need_exit():
        break

    filename = Name + '.jpg'
    print(f'[{i}/17] 请将 {Name} 放入画面中央，触摸屏幕拍照...')

    # ---- 预览循环：实时显示摄像头画面，等待触摸拍照 ----
    snapshot = None
    while not app.need_exit():
        live = capture_frame()
        if live is None:
            continue

        # 在预览画面上叠加提示文字
        hint = live.copy()
        cv2.putText(hint, f'Touch to capture: {Name}',
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.7, (0, 255, 0), 2, cv2.LINE_AA)
        show_cv_image(hint)

        x, y, pressed = ts.read()
        if pressed:
            snapshot = live.copy()
            # 等待手指抬起
            while not app.need_exit():
                _, _, p = ts.read()
                if not p:
                    break
            break

    if snapshot is None:
        print('未能获取图像，跳过...')
        i += 1
        continue

    # ---- 图像处理：找到卡牌并展平 ----
    gray  = cv2.cvtColor(snapshot, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 100, 255, cv2.THRESH_BINARY)

    # ★ 适配点: OpenCV 4.x findContours 返回 2 个值
    cnts, hier = cv2.findContours(thresh, cv2.RETR_TREE,
                                  cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)

    if len(cnts) == 0:
        print('未找到轮廓，跳过...')
        i += 1
        continue

    card   = cnts[0]
    peri   = cv2.arcLength(card, True)
    approx = cv2.approxPolyDP(card, 0.01 * peri, True)
    pts    = np.float32(approx)
    x, y, w, h = cv2.boundingRect(card)

    # 透视展平为 200×300 灰度图
    warp = Cards.flattener(snapshot, pts, w, h)

    # ---- 裁剪角落并放大 ----
    corner       = warp[0:84, 0:32]
    corner_zoom  = cv2.resize(corner, (0, 0), fx=4, fy=4)
    corner_blur  = cv2.GaussianBlur(corner_zoom, (5, 5), 0)
    _, corner_thresh = cv2.threshold(corner_blur, 155, 255,
                                     cv2.THRESH_BINARY_INV)

    # ---- 根据序号决定裁剪点数还是花色 ----
    if i <= 13:  # 点数 (Ace ~ King)
        roi_thresh = corner_thresh[20:185, 0:128]

        # ★ 适配点: OpenCV 4.x
        rank_cnts, _ = cv2.findContours(roi_thresh, cv2.RETR_TREE,
                                        cv2.CHAIN_APPROX_SIMPLE)
        rank_cnts = sorted(rank_cnts, key=cv2.contourArea, reverse=True)

        if len(rank_cnts) == 0:
            print(f'未找到点数轮廓，跳过 {Name}...')
            i += 1
            continue

        rx, ry, rw, rh = cv2.boundingRect(rank_cnts[0])
        rank_roi   = roi_thresh[ry:ry+rh, rx:rx+rw]
        final_img  = cv2.resize(rank_roi, (RANK_WIDTH, RANK_HEIGHT))

    else:        # 花色 (Spades ~ Hearts)
        roi_thresh = corner_thresh[186:336, 0:128]

        # ★ 适配点: OpenCV 4.x
        suit_cnts, _ = cv2.findContours(roi_thresh, cv2.RETR_TREE,
                                        cv2.CHAIN_APPROX_SIMPLE)
        suit_cnts = sorted(suit_cnts, key=cv2.contourArea, reverse=True)

        if len(suit_cnts) == 0:
            print(f'未找到花色轮廓，跳过 {Name}...')
            i += 1
            continue

        sx, sy, sw, sh = cv2.boundingRect(suit_cnts[0])
        suit_roi   = roi_thresh[sy:sy+sh, sx:sx+sw]
        final_img  = cv2.resize(suit_roi, (SUIT_WIDTH, SUIT_HEIGHT))

    # ---- 显示结果，等待确认保存 ----
    # 将单通道图转为 BGR 以便叠加文字
    preview = cv2.cvtColor(final_img, cv2.COLOR_GRAY2BGR)
    cv2.putText(preview, 'Touch to SAVE',
                (2, 15), cv2.FONT_HERSHEY_SIMPLEX,
                0.4, (0, 200, 0), 1, cv2.LINE_AA)

    print(f'识别结果预览中，触摸屏幕保存 {filename}...')

    # 放大预览以便看清（缩略图太小）
    preview_big = cv2.resize(preview, (280, 400))
    show_cv_image(preview_big)

    # 等待触摸确认
    wait_touch_release()

    # 保存到 Card_Imgs 目录
    save_path = img_path + filename
    cv2.imwrite(save_path, final_img)
    print(f'已保存: {save_path}')

    i += 1
    time.sleep(0.3)  # 短暂延迟防误触

print('全部训练图像采集完成！')