from maix import camera as maix_camera
from maix import image as maix_image

class VideoStream:
    """MaixCam Pro 摄像头封装，保持与原始接口兼容"""

    def __init__(self, resolution=(640, 480), framerate=30, PiOrUSB=1, src=0):
        self.width  = resolution[0]
        self.height = resolution[1]
        self.stopped = False

        # MaixCam Pro 使用 maix.camera，直接请求 BGR 格式省去转换开销
        self.cam = maix_camera.Camera(self.width, self.height,
                                      maix_image.Format.FMT_BGR888)

    def start(self):
        # maix.camera 内部已经是异步采集，不需要额外线程
        return self

    def read(self):
        """
        读取最新一帧，返回 BGR numpy 数组（uint8, shape=(H,W,3)）
        与原始 VideoStream 接口完全兼容。
        """
        img = self.cam.read()
        if img is None:
            return None
        # ensure_bgr=True 保证通道顺序为 BGR，copy=False 避免额外内存拷贝
        return maix_image.image2cv(img, ensure_bgr=True, copy=False)

    def stop(self):
        self.stopped = True
        # maix.camera 对象析构时自动释放底层资源