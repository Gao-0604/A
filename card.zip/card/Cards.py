import numpy as np
import cv2
import time

### -------- 常量 -------- ###

# 自适应阈值参数
BKG_THRESH  = 60
CARD_THRESH = 30

# 卡牌角落区域尺寸（含点数和花色）
CORNER_WIDTH  = 32
CORNER_HEIGHT = 84

# 训练图像尺寸
RANK_WIDTH  = 70
RANK_HEIGHT = 125
SUIT_WIDTH  = 70
SUIT_HEIGHT = 100

RANK_DIFF_MAX = 3000
SUIT_DIFF_MAX = 2500

CARD_MAX_AREA = 120000
CARD_MIN_AREA = 25000

font = cv2.FONT_HERSHEY_SIMPLEX

### -------- 数据结构 -------- ###

class Query_card:
    """存储摄像头图像中待识别卡牌的信息"""
    def __init__(self):
        self.contour         = []        # 卡牌轮廓
        self.width           = 0
        self.height          = 0
        self.corner_pts      = []        # 四角坐标
        self.center          = []        # 中心点
        self.warp            = []        # 200x300 展平灰度图
        self.rank_img        = []        # 点数图像（阈值化后）
        self.suit_img        = []        # 花色图像（阈值化后）
        self.best_rank_match = "Unknown"
        self.best_suit_match = "Unknown"
        self.rank_diff       = 0
        self.suit_diff       = 0

class Train_ranks:
    """存储训练集点数图像"""
    def __init__(self):
        self.img  = []
        self.name = "Placeholder"

class Train_suits:
    """存储训练集花色图像"""
    def __init__(self):
        self.img  = []
        self.name = "Placeholder"

### -------- 函数 -------- ###

def load_ranks(filepath):
    """从 filepath 目录加载点数训练图像，返回 Train_ranks 列表"""
    train_ranks = []
    for i, Rank in enumerate(['A', '2', '3', '4', '5', '6',
                               '7', '8', '9', '10',
                               'J', 'Q', 'K']):
        tr = Train_ranks()
        tr.name = Rank
        tr.img  = cv2.imread(filepath + Rank + '.jpg', cv2.IMREAD_GRAYSCALE)
        train_ranks.append(tr)
    return train_ranks

def load_suits(filepath):
    """从 filepath 目录加载花色训练图像，返回 Train_suits 列表"""
    train_suits = []
    for i, Suit in enumerate(['Spade', 'Diamond', 'Club', 'Heart']):
        ts = Train_suits()
        ts.name = Suit
        ts.img  = cv2.imread(filepath + Suit + '.jpg', cv2.IMREAD_GRAYSCALE)
        train_suits.append(ts)
    return train_suits

def preprocess_image(image):
    """对摄像头帧做灰度→高斯模糊→自适应二值化，返回阈值图"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    img_w, img_h = np.shape(image)[:2]
    bkg_level  = gray[int(img_h / 100)][int(img_w / 2)]
    thresh_level = bkg_level + BKG_THRESH

    _, thresh = cv2.threshold(blur, thresh_level, 255, cv2.THRESH_BINARY)
    return thresh

def find_cards(thresh_image):
    """
    在阈值图中寻找所有卡牌大小的轮廓。
    返回: (按面积降序排列的轮廓列表, 对应是否为卡牌的标记数组)

    ★ 适配点: OpenCV 4.x findContours 只返回 2 个值
    """
    # OpenCV 4.x: 只返回 (contours, hierarchy)
    cnts, hier = cv2.findContours(thresh_image,
                                  cv2.RETR_TREE,
                                  cv2.CHAIN_APPROX_SIMPLE)

    # 按轮廓面积降序排列索引
    index_sort = sorted(range(len(cnts)),
                        key=lambda i: cv2.contourArea(cnts[i]),
                        reverse=True)

    if len(cnts) == 0:
        return [], []

    cnts_sort    = []
    hier_sort    = []
    cnt_is_card  = np.zeros(len(cnts), dtype=int)

    for i in index_sort:
        cnts_sort.append(cnts[i])
        hier_sort.append(hier[0][i])

    for i in range(len(cnts_sort)):
        size  = cv2.contourArea(cnts_sort[i])
        peri  = cv2.arcLength(cnts_sort[i], True)
        approx = cv2.approxPolyDP(cnts_sort[i], 0.01 * peri, True)

        if (size  < CARD_MAX_AREA and
            size  > CARD_MIN_AREA and
            hier_sort[i][3] == -1 and
            len(approx) == 4):
            cnt_is_card[i] = 1

    return cnts_sort, cnt_is_card

def preprocess_card(contour, image):
    """
    利用轮廓提取卡牌信息：角点、中心、展平图、点数/花色图像。

    ★ 适配点: OpenCV 4.x findContours 只返回 2 个值（共 2 处）
    """
    qCard = Query_card()
    qCard.contour = contour

    peri   = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.01 * peri, True)
    pts    = np.float32(approx)
    qCard.corner_pts = pts

    x, y, w, h = cv2.boundingRect(contour)
    qCard.width, qCard.height = w, h

    average = np.sum(pts, axis=0) / len(pts)
    qCard.center = [int(average[0][0]), int(average[0][1])]

    qCard.warp = flattener(image, pts, w, h)

    # 角落放大 4 倍
    Qcorner      = qCard.warp[0:CORNER_HEIGHT, 0:CORNER_WIDTH]
    Qcorner_zoom = cv2.resize(Qcorner, (0, 0), fx=4, fy=4)

    white_level  = Qcorner_zoom[15, int((CORNER_WIDTH * 4) / 2)]
    thresh_level = white_level - CARD_THRESH
    if thresh_level <= 0:
        thresh_level = 1

    _, query_thresh = cv2.threshold(Qcorner_zoom, thresh_level, 255,
                                    cv2.THRESH_BINARY_INV)

    Qrank = query_thresh[20:185,  0:128]
    Qsuit = query_thresh[186:336, 0:128]

    # ★ 适配点1: 点数轮廓查找
    Qrank_cnts, _ = cv2.findContours(Qrank, cv2.RETR_TREE,
                                     cv2.CHAIN_APPROX_SIMPLE)
    Qrank_cnts = sorted(Qrank_cnts, key=cv2.contourArea, reverse=True)
    if len(Qrank_cnts) != 0:
        x1, y1, w1, h1 = cv2.boundingRect(Qrank_cnts[0])
        Qrank_roi       = Qrank[y1:y1+h1, x1:x1+w1]
        qCard.rank_img  = cv2.resize(Qrank_roi, (RANK_WIDTH, RANK_HEIGHT))

    # ★ 适配点2: 花色轮廓查找
    Qsuit_cnts, _ = cv2.findContours(Qsuit, cv2.RETR_TREE,
                                     cv2.CHAIN_APPROX_SIMPLE)
    Qsuit_cnts = sorted(Qsuit_cnts, key=cv2.contourArea, reverse=True)
    if len(Qsuit_cnts) != 0:
        x2, y2, w2, h2 = cv2.boundingRect(Qsuit_cnts[0])
        Qsuit_roi       = Qsuit[y2:y2+h2, x2:x2+w2]
        qCard.suit_img  = cv2.resize(Qsuit_roi, (SUIT_WIDTH, SUIT_HEIGHT))

    return qCard

def match_card(qCard, train_ranks, train_suits):
    """
    将查询卡牌的点数/花色图像与训练图像做差分匹配。
    返回: (最佳点数名, 最佳花色名, 点数差值, 花色差值)
    """
    best_rank_match_diff = 10000
    best_suit_match_diff = 10000
    best_rank_match_name = "Unknown"
    best_suit_match_name = "Unknown"
    best_rank_name       = "Unknown"
    best_suit_name       = "Unknown"

    if len(qCard.rank_img) != 0 and len(qCard.suit_img) != 0:

        for Trank in train_ranks:
            diff_img   = cv2.absdiff(qCard.rank_img, Trank.img)
            rank_diff  = int(np.sum(diff_img) / 255)
            if rank_diff < best_rank_match_diff:
                best_rank_match_diff = rank_diff
                best_rank_name       = Trank.name

        for Tsuit in train_suits:
            diff_img   = cv2.absdiff(qCard.suit_img, Tsuit.img)
            suit_diff  = int(np.sum(diff_img) / 255)
            if suit_diff < best_suit_match_diff:
                best_suit_match_diff = suit_diff
                best_suit_name       = Tsuit.name

    if best_rank_match_diff < RANK_DIFF_MAX:
        best_rank_match_name = best_rank_name
    if best_suit_match_diff < SUIT_DIFF_MAX:
        best_suit_match_name = best_suit_name

    return best_rank_match_name, best_suit_match_name, \
           best_rank_match_diff, best_suit_match_diff

def draw_results(image, qCard):
    """在图像上绘制卡牌中心点和识别结果"""
    x = qCard.center[0]
    y = qCard.center[1]
    cv2.circle(image, (x, y), 5, (255, 0, 0), -1)

    rank_name = qCard.best_rank_match
    suit_name = qCard.best_suit_match

    # 双层绘制文字，产生黑色描边效果
    cv2.putText(image, (rank_name + ' of'), (x-60, y-10),
                font, 1, (0, 0, 0), 3, cv2.LINE_AA)
    cv2.putText(image, (rank_name + ' of'), (x-60, y-10),
                font, 1, (50, 200, 200), 2, cv2.LINE_AA)

    cv2.putText(image, suit_name, (x-60, y+25),
                font, 1, (0, 0, 0), 3, cv2.LINE_AA)
    cv2.putText(image, suit_name, (x-60, y+25),
                font, 1, (50, 200, 200), 2, cv2.LINE_AA)

    return image

def flattener(image, pts, w, h):
    """
    将卡牌图像透视变换为 200×300 的俯视展平图，返回灰度图。
    参考: www.pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/
    """
    temp_rect = np.zeros((4, 2), dtype="float32")

    s    = np.sum(pts, axis=2)
    tl   = pts[np.argmin(s)]
    br   = pts[np.argmax(s)]
    diff = np.diff(pts, axis=-1)
    tr   = pts[np.argmin(diff)]
    bl   = pts[np.argmax(diff)]

    if w <= 0.8 * h:          # 竖向
        temp_rect[0] = tl
        temp_rect[1] = tr
        temp_rect[2] = br
        temp_rect[3] = bl

    if w >= 1.2 * h:          # 横向
        temp_rect[0] = bl
        temp_rect[1] = tl
        temp_rect[2] = tr
        temp_rect[3] = br

    if 0.8 * h < w < 1.2 * h: # 菱形方向
        if pts[1][0][1] <= pts[3][0][1]:
            temp_rect[0] = pts[1][0]
            temp_rect[1] = pts[0][0]
            temp_rect[2] = pts[3][0]
            temp_rect[3] = pts[2][0]
        else:
            temp_rect[0] = pts[0][0]
            temp_rect[1] = pts[3][0]
            temp_rect[2] = pts[2][0]
            temp_rect[3] = pts[1][0]

    maxWidth  = 200
    maxHeight = 300

    dst = np.array([[0, 0],
                    [maxWidth-1, 0],
                    [maxWidth-1, maxHeight-1],
                    [0, maxHeight-1]], dtype="float32")

    M    = cv2.getPerspectiveTransform(temp_rect, dst)
    warp = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
    warp = cv2.cvtColor(warp, cv2.COLOR_BGR2GRAY)

    return warp