############## Python-OpenCV Playing Card Detector (MaixCam Pro 适配版) ###############
#
# 原作者: Evan Juras
# 适配说明:
#   1. 摄像头采集改用 maix.camera（通过 VideoStream 封装）
#   2. 图像显示改用 maix.display（替换 cv2.imshow）
#   3. 退出检测改用 app.need_exit()（替换 cv2.waitKey 'q'）
#   4. 分辨率降至 640×480，减轻 CPU 负担
#

import cv2
import numpy as np
import time
import os

import Cards
import VideoStream

from maix import display, app
from maix import image as maix_image

### -------- 初始化 -------- ###

## 摄像头参数（MaixCam Pro 推荐 640×480，可适当提高至 800×600）
IM_WIDTH   = 480
IM_HEIGHT  = 480
FRAME_RATE = 30

## 帧率计算辅助变量
frame_rate_calc = 1
freq = cv2.getTickFrequency()

## 字体
font = cv2.FONT_HERSHEY_SIMPLEX

## 初始化 MaixCam Pro 显示屏
disp = display.Display()

## 初始化摄像头（MaixCam Pro 适配版 VideoStream）
videostream = VideoStream.VideoStream(
    (IM_WIDTH, IM_HEIGHT), FRAME_RATE, 1, 0
).start()
time.sleep(0.5)  # 等待摄像头稳定

## 加载训练图像（点数 + 花色）
path        = os.path.dirname(os.path.abspath(__file__))
train_ranks = Cards.load_ranks(path + '/Card_Imgs/')
train_suits = Cards.load_suits(path + '/Card_Imgs/')

### -------- 主循环 -------- ###
# app.need_exit() 在收到系统退出信号（如 MaixVision 停止按钮）时返回 True

while not app.need_exit():

    # 1. 从 VideoStream 读取 BGR numpy 帧
    image = videostream.read()
    if image is None:
        continue

    # 2. 开始计时（用于帧率计算）
    t1 = cv2.getTickCount()

    # 3. 预处理：灰度 → 模糊 → 自适应阈值
    pre_proc = Cards.preprocess_image(image)

    # 4. 寻找并排序卡牌轮廓
    cnts_sort, cnt_is_card = Cards.find_cards(pre_proc)

    # 5. 对每个疑似卡牌进行识别和标注
    if len(cnts_sort) != 0:
        cards = []
        k = 0

        for i in range(len(cnts_sort)):
            if cnt_is_card[i] == 1:
                # 提取卡牌属性（角点、点数图、花色图等）
                cards.append(Cards.preprocess_card(cnts_sort[i], image))

                # 模板匹配识别点数和花色
                (cards[k].best_rank_match,
                 cards[k].best_suit_match,
                 cards[k].rank_diff,
                 cards[k].suit_diff) = Cards.match_card(
                     cards[k], train_ranks, train_suits)

                # 在图像上绘制识别结果
                image = Cards.draw_results(image, cards[k])
                k += 1

        # 绘制所有卡牌轮廓（必须一次性绘制，否则显示异常）
        if len(cards) != 0:
            temp_cnts = [cards[i].contour for i in range(len(cards))]
            cv2.drawContours(image, temp_cnts, -1, (255, 0, 0), 2)

    # 6. 在左上角绘制实时帧率
    cv2.putText(image,
                "FPS: " + str(int(frame_rate_calc)),
                (10, 26), font, 0.7, (255, 0, 255), 2, cv2.LINE_AA)

    # 7. ★ 关键适配：将 BGR numpy 数组转为 maix.image.Image 并推送到屏幕
    #    bgr=True  → 告知 maix 当前是 BGR 顺序
    #    copy=False → 零拷贝，提升性能
    disp_img = maix_image.cv2image(image, bgr=True, copy=False)
    disp.show(disp_img)

    # 8. 计算本帧耗时并更新帧率
    t2     = cv2.getTickCount()
    time1  = (t2 - t1) / freq
    frame_rate_calc = 1 / time1 if time1 > 0 else 1

### -------- 退出清理 -------- ###
videostream.stop()